<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

$link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: " . mysqli_connect_error());

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($link, $_POST["username"]);
    $password = mysqli_real_escape_string($link, $_POST["password"]);
    $role = mysqli_real_escape_string($link, $_POST["role"]);

    // Check if the username already exists
    $check_query = "SELECT * FROM users WHERE username = '$username'";
    $check_result = mysqli_query($link, $check_query);

    if ($check_result && mysqli_num_rows($check_result) > 0) {
        $error_message = "Username already exists. Please choose a different one.";
    } else {
        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $insert_query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashedPassword', '$role')";
        $insert_result = mysqli_query($link, $insert_query);

        if ($insert_result) {
            // Redirect to homepage.html after successful registration
            header("Location: homepage.html");
            exit;
        } else {
            $error_message = "Error registering user: " . mysqli_error($link);
        }
    }
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .navbar {
            background-color: rgba(255, 255, 255, 0.8);
            z-index: 1000;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav {
            margin-left: auto;
        }

        .navbar-nav .nav-item {
            margin-right: 10px;
        }

        body::before {
            content: "";
            background: url('R3.jpg') no-repeat center center fixed;
            background-size: cover;
            filter: blur(5px); /* Adjust the blur amount as needed */
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: -1; /* Ensure the pseudo-element is behind the content */
        }

        .form-container {
            max-width: 300px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
            margin-top: 20px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        label {
            display: block;
            text-align: left;
            margin: 10px 0 5px;
            color: #555;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #87CEEB;
            color: #fff;
            cursor: pointer;
        }

        p {
            color: <?php echo isset($error_message) ? 'red' : 'green'; ?>;
            margin-top: -10px;
            text-align: center;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="homepage.html">Ease Pharma</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="homepage.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.html">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="conatact.html">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-signup" href="signup.php">Signup</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="form-container">
        <h2>Signup</h2>
        <form method="post" action="">
            <label for="username">Username:</label>
            <input type="text" name="username" required><br>

            <label for="password">Password:</label>
            <input type="password" name="password" required><br>

            <label for="role">Role:</label>
            <select name="role" required>
                <option value="admin">Admin</option>
                <option value="customer">Customer</option>
            </select><br>

            <input type="submit" value="Signup">
        </form>
        <?php if (isset($error_message) || isset($success_message)) : ?>
            <p><?php echo isset($error_message) ? $error_message : $success_message; ?></p>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
