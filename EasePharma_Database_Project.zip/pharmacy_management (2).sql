-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 18, 2023 at 04:48 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `buys`
--

DROP TABLE IF EXISTS `buys`;
CREATE TABLE IF NOT EXISTS `buys` (
  `customer_id` int NOT NULL,
  `medicine_id` int NOT NULL,
  PRIMARY KEY (`customer_id`,`medicine_id`),
  KEY `medicine_id` (`medicine_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `buys`
--

INSERT INTO `buys` (`customer_id`, `medicine_id`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `prescription_id` int DEFAULT NULL,
  `date` date DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `name`, `contact_info`, `prescription_id`, `date`, `doctor_name`) VALUES
(1, 'Alice Johnson', '555-1234', NULL, NULL, NULL),
(2, 'Charlie Brown', '555-5678', NULL, NULL, NULL),
(3, 'Eve Wilson', '555-9876', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `high_cost_medicines`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `high_cost_medicines`;
CREATE TABLE IF NOT EXISTS `high_cost_medicines` (
`medicine_id` int
,`medicine_name` varchar(255)
,`price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
CREATE TABLE IF NOT EXISTS `medicine` (
  `medicine_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `func` varchar(255) DEFAULT 'Not Specified',
  `stock` int DEFAULT NULL,
  PRIMARY KEY (`medicine_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`medicine_id`, `name`, `manufacturer`, `expiry_date`, `price`, `func`, `stock`) VALUES
(1, 'Aspirin', 'Bayer', '2023-12-31', '5.99', 'Pain relief', 38),
(2, 'Dispirin', 'Reckitts & Benckiser ', '2024-11-21', '32.00', 'Pain ', 38),
(3, 'Paracetamol', 'pfizer', '2024-11-21', '6.00', 'Pain', 40),
(4, 'Amoxicillin', 'GSK', '2024-05-01', '12.99', 'Antibiotic', 40),
(5, 'Loratadine', 'Novartis', '2023-09-30', '6.49', 'Antihistamine', 40),
(6, 'Metformin', 'Merck', '2023-08-15', '8.49', 'Antidiabetic', 40),
(7, 'Simvastatin', 'Roche', '2023-07-10', '11.99', 'Cholesterol-lowering', 40),
(8, 'Ciprofloxacin', 'Sanofi', '2024-04-05', '14.99', 'Antibiotic', 40),
(9, 'Diazepam', 'Pfizer', '2023-06-22', '7.99', 'Anxiolytic', 40),
(10, 'Ranitidine', 'GSK', '2023-05-12', '4.99', 'Acid reducer', 40),
(11, 'Codeine', 'Johnson & Johnson', '2023-03-25', '8.99', 'Analgesic', 40),
(12, 'Metoprolol', 'Merck', '2023-07-01', '10.49', 'Beta blocker', 40),
(13, 'Amlodipine', 'Sanofi', '2023-11-30', '11.99', 'Calcium channel blocker', 40),
(14, 'Morphine', 'Roche', '2024-06-15', '15.99', 'Analgesic', 40),
(15, 'Gabapentin', 'Novartis', '2023-09-05', '12.49', 'Anticonvulsant', 40),
(16, 'Tadalafil', 'Pfizer', '2024-03-10', '17.99', 'Erectile dysfunction', 40),
(17, 'Levothyroxine', 'AstraZeneca', '2023-08-20', '6.49', 'Thyroid hormone', 40),
(18, 'Hydrochlorothiazide', 'Johnson & Johnson', '2023-12-05', '8.99', 'Diuretic', 40),
(19, 'Fluoxetine', 'Pfizer', '2023-04-30', '11.49', 'Antidepressant', 40),
(20, 'Alprazolam', 'GSK', '2024-02-18', '9.99', 'Anxiolytic', 40),
(21, 'Clarithromycin', 'Novartis', '2023-10-10', '13.99', 'Antibiotic', 40),
(22, 'Naproxen', 'Merck', '2023-06-01', '7.49', 'Pain relief', 38),
(23, 'Digoxin', 'Roche', '2024-01-15', '12.99', 'Heart failure', 40),
(24, 'Carvedilol', 'Sanofi', '2023-03-28', '10.99', 'Beta blocker', 40),
(25, 'Clonazepam', 'Pfizer', '2024-05-22', '14.49', 'Antiepileptic', 40),
(26, 'Cefuroxime', 'AstraZeneca', '2023-09-18', '11.99', 'Antibiotic', 40),
(27, 'Dexamethasone', 'Johnson & Johnson', '2023-11-02', '8.99', 'Anti-inflammatory', 40),
(28, 'Furosemide', 'Pfizer', '2024-04-12', '9.49', 'Diuretic', 40),
(29, 'Venlafaxine', 'GSK', '2023-05-25', '15.99', 'Antidepressant', 40),
(30, 'Levofloxacin', 'Merck', '2023-12-22', '13.49', 'Antibiotic', 40),
(31, 'Losartan', 'Sanofi', '2023-01-20', '11.99', 'Antihypertensive', 40),
(32, 'Meloxicam', 'Roche', '2024-02-10', '10.49', 'Anti-inflammatory', 40),
(33, 'Methotrexate', 'Pfizer', '2023-08-05', '14.99', 'Immunosuppressant', 40),
(34, 'Sildenafil', 'AstraZeneca', '2023-10-28', '16.99', 'Erectile dysfunction', 40),
(35, 'Tramadol', 'Johnson & Johnson', '2024-03-05', '12.99', 'Analgesic', 40),
(36, 'Fentanyl', 'Pfizer', '2023-06-08', '18.99', 'Analgesic', 40),
(37, 'Mirtazapine', 'GSK', '2024-01-02', '9.99', 'Antidepressant', 40),
(38, 'Clopidogrel', 'Novartis', '2023-04-15', '11.49', 'Antiplatelet', 40),
(39, 'Cefixime', 'Merck', '2023-07-30', '7.99', 'Antibiotic', 40),
(40, 'Trazodone', 'Roche', '2023-09-12', '8.49', 'Antidepressant', 40),
(41, 'Duloxetine', 'Sanofi', '2024-05-28', '13.99', 'Antidepressant', 40),
(42, 'Amitriptyline', 'Pfizer', '2023-11-18', '6.99', 'Antidepressant', 40),
(43, 'Hydrocodone', 'AstraZeneca', '2023-02-25', '16.49', 'Analgesic', 40),
(44, 'Cephalexin', 'Pfizer', '2023-03-18', '10.99', 'Antibiotic', 40),
(45, 'Zyrtec', 'pfizer', '2024-01-01', '21.00', 'Throat Infection', 40),
(46, 'Zyrtec', 'pfizer', '2024-01-01', '21.00', 'Throat Infection', 40),
(47, 'Ibuprofen', 'Johnson & Johnson', '2024-09-17', '45.00', 'Anti-Inflammatory', 40),
(48, 'Ibuprofen', 'Johnson & Johnson', '2024-09-17', '45.00', 'Anti-Inflammatory', 67);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacystore`
--

DROP TABLE IF EXISTS `pharmacystore`;
CREATE TABLE IF NOT EXISTS `pharmacystore` (
  `store_id` int NOT NULL AUTO_INCREMENT,
  `store_name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `emp_id` int DEFAULT NULL,
  `emp_name` varchar(22) DEFAULT NULL,
  `emp_position` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pharmacystore`
--

INSERT INTO `pharmacystore` (`store_id`, `store_name`, `location`, `emp_id`, `emp_name`, `emp_position`) VALUES
(1, 'Main Pharmacy', '123 Main Street', NULL, NULL, NULL),
(2, 'City Pharmacy', '456 City Avenue', NULL, NULL, NULL),
(3, 'Suburb Pharmacy', '789 Suburb Lane', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sells`
--

DROP TABLE IF EXISTS `sells`;
CREATE TABLE IF NOT EXISTS `sells` (
  `store_id` int NOT NULL,
  `medicine_id` int NOT NULL,
  PRIMARY KEY (`store_id`,`medicine_id`),
  KEY `medicine_id` (`medicine_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sells`
--

INSERT INTO `sells` (`store_id`, `medicine_id`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `name`, `contact_info`) VALUES
(1, 'MedSupply Inc.', '555-1111'),
(2, 'PharmaHub', '555-2222'),
(3, 'DrugLink', '555-3333');

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

DROP TABLE IF EXISTS `supplies`;
CREATE TABLE IF NOT EXISTS `supplies` (
  `supplier_id` int NOT NULL,
  `medicine_id` int NOT NULL,
  PRIMARY KEY (`supplier_id`,`medicine_id`),
  KEY `medicine_id` (`medicine_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplies`
--

INSERT INTO `supplies` (`supplier_id`, `medicine_id`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'tooba', '$2y$10$6sNDPDm6Pcksvv/VXBPIPeLO.xOkMfFVPjUgA5OO2R5sBlkgAadre', 'admin'),
(2, 'danial', '$2y$10$JAOQgJNlr.U7P33N4ZRaSeAYKCFkH9/JSQaI7Dh3iUaWlO2r3xFRS', 'customer'),
(3, 'Qurat ul ain', '$2y$10$rvrAPxYLIT8klJSo3DODu.J2cZyvRu75bSEEjjrTVfsUIV.UQplKi', 'admin'),
(4, 'misho', '$2y$10$b3Sm0uoB96Xweppx3LKl/.1Zsu/5syOvWKsqkWBm.BvIFNU1q3V6y', 'customer'),
(5, 'Musarat', '$2y$10$ntrLfj3rZ5Z3wwCl91cMTuq/AAoJwxPkxits/gzCCb9a.1Vz8/sPy', 'customer'),
(6, 'gh', '$2y$10$7tfbIFr0n6f8YExYnw8gHeNnguDY3zcfZia/ifkclIYREUf1fP56q', 'customer'),
(7, 'qwerty', '$2y$10$5NsBvYclhhKfSHXVsSD7aOHPWfWlJt1SQwOeQplxd2wcQ5Lf0SrtO', 'customer'),
(8, 'Sana', '$2y$10$/oUiBl6E8fDLV3SALEkH4Oi/3RbX8FaAcjKMS4nj/WiISEnT2kEfu', 'admin'),
(10, 'Shan Ahmed', '$2y$10$xIg9uxDVVoI8wxhwMN50cOn9p7WsMbVpD5hVHymRTg8Re.OAvc1l2', 'customer'),
(11, 'Qudsia', '$2y$10$JEz8zn8Jx3qT/z1OLSegO.AzAg1aXknfO6.WhRPaHDDXuRIydNhTO', 'admin'),
(12, 'Noor', '$2y$10$J5AB.qW9s8BKtcpkfTzQzOk1viQBVEMYCRaMMrxX3ljdSP6xSU08i', 'customer');

-- --------------------------------------------------------

--
-- Structure for view `high_cost_medicines`
--
DROP TABLE IF EXISTS `high_cost_medicines`;

DROP VIEW IF EXISTS `high_cost_medicines`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `high_cost_medicines`  AS SELECT `medicine`.`medicine_id` AS `medicine_id`, `medicine`.`name` AS `medicine_name`, `medicine`.`price` AS `price` FROM `medicine` WHERE (`medicine`.`price` > 10.00)  ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
