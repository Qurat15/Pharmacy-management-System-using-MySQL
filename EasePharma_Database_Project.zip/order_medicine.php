<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

// Connect to your database (replace these credentials with your actual database credentials)
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

$link = mysqli_connect($hostname, $user, $pass, $db);

if (!$link) {
    die("Could not connect to the database: " . mysqli_connect_error());
}

// Fetch the list of medicines from your database
$query = "SELECT * FROM medicine";
$result = mysqli_query($link, $query);

if (!$result) {
    die("Error executing query: " . mysqli_error($link));
}

$medicines = mysqli_fetch_all($result, MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the form submission to generate the receipt
    // Redirect to generate_receipt.php with selected medicine and quantity
    $medicine_name = urlencode($_POST['medicine_name']);
    $quantity = (int)$_POST['quantity'];

    // Retrieve the current stock for the selected medicine
    $query = "SELECT stock FROM medicine WHERE name = ?";
    $stmt = mysqli_prepare($link, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $medicine_name);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result) {
            $currentStockRow = mysqli_fetch_assoc($result);

            // Check if there are rows in the result set
            if ($currentStockRow !== null) {
                $currentStock = $currentStockRow['stock'];

                // Check if there is enough stock to fulfill the order
                if ($currentStock >= $quantity) {
                    // Update the stock in the database
                    $newStock = $currentStock - $quantity;
                    $updateQuery = "UPDATE medicine SET stock = ? WHERE name = ?";
                    $updateStmt = mysqli_prepare($link, $updateQuery);

                    if ($updateStmt) {
                        mysqli_stmt_bind_param($updateStmt, "is", $newStock, $medicine_name);
                        mysqli_stmt_execute($updateStmt);

                        // Redirect to generate_receipt.php
                        header('Location: generate_receipt.php?medicine_name=' . $medicine_name . '&quantity=' . $quantity);
                        exit();
                    } else {
                        die("Error preparing update statement: " . mysqli_error($link));
                    }
                } else {
                    echo "Insufficient stock to fulfill the order.";
                }
            } else {
                echo "Medicine not found in the database."; // Handle the case where no rows are found
            }
        } else {
            die("Error executing stock query: " . mysqli_error($link));
        }

        mysqli_stmt_close($stmt);
    } else {
        die("Error preparing stock query: " . mysqli_error($link));
    }
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Medicine</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: rgba(0,0,0,0.9) url('R.png') no-repeat center center fixed;

	    filter: blur(5px)
            margin: 0;
            padding: 0;
            color: #fff;
        }

        h1 {
            margin-top: 50px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            width: 80%;
        }

        th,
        td {
            padding: 15px;
            border: 1px solid #dddddd;
            text-align: left;
            color: white;
        }

        th {
            background-color: #87CEEB;
            color: white;
        }

        form {
            max-width: 950px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            display: block;
            text-align: left;
            margin: 10px 0 5px;
            color: #333;
            font-weight: bold;
        }

        select,
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #87CEEB;
            color: #fff;
            cursor: pointer;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #5CACEE;
        }
    </style>
</head>

<body>

    <!-- Background Container for Blur -->
    <div class='background-container'></div>

    <nav class='navbar navbar-expand-lg navbar-dark bg-dark'>
        <a class='navbar-brand' href='user_page.html'>Ease Pharma</a>
        <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNav'
            aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
            <span class='navbar-toggler-icon'></span>
        </button>
        <div class='collapse navbar-collapse' id='navbarNav'>
            <ul class='navbar-nav ml-auto'>

                <li class='nav-item'>
                    <a class='nav-link' href='view_med_user.php'>View Medicines</a>
                </li>
		 <li class='nav-item'>
                    <a class='nav-link' href='order_medicine.php'>Order Medicines</a>
                </li>

            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Order Medicine</h1>

        <form method="post" action="" id="orderForm">
            <div class="form-group">
                <label for="function">Search by Function:</label>
                <input type="text" class="form-control" name="function" id="function" placeholder="Enter function" oninput="filterMedicines()">
            </div>

            <div class="form-group">
                <label for="medicine_name">Enter Medicine Name:</label>
                <input type="text" class="form-control" name="medicine_name" id="medicine_name" placeholder="Enter medicine name" required>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" class="form-control" name="quantity" required>
            </div>

            <input type="submit" class="btn btn-primary" value="Order Medicine">
        </form>

        <!-- Display the list of medicines based on the entered function -->
        <table class="table table-bordered" id="medicineTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Medicine Name</th>
                    <th>Manufacturer</th>
                    <th>Expiry Date</th>
                    <th>Price</th>
                    <th>Functionality</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($medicines as $medicine) : ?>
                    <tr>
                        <td><?= $medicine['medicine_id']; ?></td>
                        <td><?= $medicine['name']; ?></td>
                        <td><?= $medicine['manufacturer']; ?></td>
                        <td><?= $medicine['expiry_date']; ?></td>
                        <td>$<?= number_format($medicine['price'], 2); ?></td>
                        <td><?= $medicine['func']; ?></td>
                        <td><?= $medicine['stock']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        function filterMedicines() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("function");
            filter = input.value.toUpperCase();
            table = document.getElementById("medicineTable");
            tr = table.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[5]; // Index 5 corresponds to the "Functionality" column
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</body>

</html>
