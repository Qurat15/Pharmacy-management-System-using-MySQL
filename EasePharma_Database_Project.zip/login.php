<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

$link = mysqli_connect($hostname, $user, $pass, $db);

if (!$link) {
    die("Could not connect: " . mysqli_connect_error());
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($link, $_POST["username"]);
    $password = mysqli_real_escape_string($link, $_POST["password"]);

    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($link, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result) {
            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                if (password_verify($password, $row["password"])) {
                    $_SESSION["username"] = $username;
                    $_SESSION["role"] = $row["role"];

                    // Redirect based on the user's role
                    if ($row["role"] == "admin") {
                        header("Location: index.html"); // Redirect to index.html for admin
                    } elseif ($row["role"] == "customer") {
                        header("Location: user_page.html"); // Redirect to an empty page for customers
                    }
                    exit;
                } else {
                    $error_message = "Invalid password.";
                }
            } else {
                $error_message = "Invalid username. <a href='signup.php'>Create an account</a> and then login.";
            }
        } else {
            $error_message = "Error executing query: " . mysqli_error($link);
        }

        mysqli_stmt_close($stmt);
    } else {
        $error_message = "Error preparing query: " . mysqli_error($link);
    }
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .navbar {
            background-color: rgba(255, 255, 255, 0.8);
            z-index: 1000;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
        }

        .navbar-nav {
            margin-left: auto;
        }

        .navbar-nav .nav-item {
            margin-right: 10px;
        }

        .container-fluid {
            display: flex;
            flex: 1;
            margin: 0;
            background:url('R3.jpg') no-repeat center center fixed;
            background-size: cover;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        body::before {
            content: "";
            background: inherit;
            filter: blur(5px); /* Adjust the blur amount as needed */
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: -1; /* Ensure the pseudo-element is behind the content */
        }

        .form-container {
            max-width: 300px;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            text-align: center;
        }

        label {
            display: block;
            text-align: left;
            margin: 10px 0 5px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #87CEEB;
            color: #fff;
            cursor: pointer;
        }

        p {
            color: red;
            margin-top: -10px;
        }

        form p {
            margin-top: 10px;
            font-size: 15px;
            color: #333;
        }

        form p a {
            color: crimson;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="homepage.html">Ease Pharma</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="homepage.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.html">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-signup" href="signup.php">Signup</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="form-container">
            <h2>Login</h2>
            <?php if (isset($error_message)) echo "<p>$error_message</p>"; ?>
            <form method="post" action="">
                <label for="username">Username:</label>
                <input type="text" name="username" required>

                <label for="password">Password:</label>
                <input type="password" name="password" required>

                <input type="submit" value="Login">
                <p>Don't have an account? <a href="signup.php">Register now</a></p>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
