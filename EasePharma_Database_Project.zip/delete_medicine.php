
<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

$link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: " . mysqli_connect_error());

function adjustMedicineIDs($link) {
    // Update medicine IDs to be continuous
    $sql = "SET @counter = 0;";
    mysqli_query($link, $sql);

    $sql = "UPDATE Medicine SET medicine_id = @counter := @counter + 1;";
    mysqli_query($link, $sql);

    $sql = "ALTER TABLE Medicine AUTO_INCREMENT = 1;";
    mysqli_query($link, $sql);
}

function displayMedicineList($link) {
    // Display the updated medicine list
    $query = "SELECT * FROM Medicine";
    $result = mysqli_query($link, $query);

    echo "<h2 class='mt-5'>Medicine List</h2>";

    if (mysqli_num_rows($result) > 0) {
        echo "<table class='table table-bordered'>
                <thead class='thead-dark'>
                    <tr>
                        <th>Medicine ID</th>
                        <th>Medicine Name</th>
                        <th>Manufacturer</th>
                        <th>Expiry Date</th>
                        <th>Function</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['medicine_id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['manufacturer']}</td>
                    <td>{$row['expiry_date']}</td>
                    <td>{$row['func']}</td>
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "No records found.";
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $medicine_id = isset($_POST["medicine_id"]) ? mysqli_real_escape_string($link, $_POST["medicine_id"]) : '';

    // Validate medicine_id
    if (!empty($medicine_id)) {
        // Delete medicine from the database
        $sql = "DELETE FROM Medicine WHERE medicine_id = '$medicine_id'";
        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "<div class='alert alert-success mt-3'>Medicine deleted successfully!</div>";

            // Adjust remaining medicine IDs
            adjustMedicineIDs($link);
        } else {
            echo "<div class='alert alert-danger mt-3'>Error deleting medicine: " . mysqli_error($link) . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger mt-3'>Please enter a valid Medicine ID.</div>";
    }
}

// Display the updated medicine list
displayMedicineList($link);

// Close the connection after using it
mysqli_close($link);
?>


<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Medicine - Pharmacy Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333333;
        }

        .background-container {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('medicine.jpg') no-repeat center center fixed;
            background-size: cover;
            filter: blur(2px); /* Added slight blur to the background image */
            z-index: -1; /* Move the background behind other content */
        }

        .container {
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            margin-top: 50px;
            transition: margin-top 0.5s; /* Added transition for smooth movement */
        }

        .container.success {
            margin-top: 20px; /* Adjust the margin-top value for the success state */
        }

        h2 {
            color: #87CEEB;
        }

        table {
            background-color: #87CEEB;
            color: white;
        }

        .btn-danger {
            background-color: #87CEEB;
            border: none;
        }

        .btn-danger:hover {
            background-color: #6CA6CD;
        }
    </style>
</head>

<body>

    <!-- Background Container for Blur -->
    <div class="background-container"></div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <!-- Navbar content ... -->
    </nav>

    <div class="container mt-5">
        <h2 class="mb-4">Delete Medicine</h2>

        <!-- Form for taking entries -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group row">
                <label for="medicineId" class="col-sm-2 col-form-label">Medicine ID:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="medicineId" name="medicine_id" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10 offset-sm-2">
                    <button type="submit" class="btn btn-danger">Delete Medicine</button>
                </div>
            </div>
        </form>

        <?php
        // Display the updated medicine list
        displayMedicineList($link);
        ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
