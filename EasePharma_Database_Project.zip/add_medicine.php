


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Medicine - Pharmacy Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
 body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333333;
        }

        .background-container {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('R.png') no-repeat center center fixed;
            background-size: cover;
            filter: blur(2px); /* Added slight blur to the background image */
            z-index: -1; /* Move the background behind other content */
        }

        .container {
            margin-top: 100px; /* Adjust the margin based on your preference */
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .medicine-list {
            margin-top: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 10px;
            border: 1px solid #dddddd;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>

    <!-- Background Container for Blur -->
    <div class="background-container"></div>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Ease Pharma</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.html">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_medicine.php">Add Medicine</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_medicines.php">View Medicines</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="update_medicines.php">Update Medicine</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="delete_medicine.php">Delete Medicine</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="form-container">
            <h2>Add Medicine</h2>

           <!-- Form for taking entries -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group row">
                <label for="medicineName" class="col-sm-2 col-form-label">Medicine Name:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="medicineName" name="name" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="manufacturer" class="col-sm-2 col-form-label">Manufacturer:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="manufacturer" name="manufacturer" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="expiryDate" class="col-sm-2 col-form-label">Expiry Date:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="expiryDate" name="expiry_date" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-sm-2 col-form-label">Price:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="price" name="price" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="func" class="col-sm-2 col-form-label">Function:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="func" name="func" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="stock" class="col-sm-2 col-form-label">Stock:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="stock" name="stock" required>
                </div>
            </div>

                <div class="form-group row">
                    <div class="col-sm-10 offset-sm-2">
                        <button type="submit" class="btn btn-primary">Add Medicine</button>
                    </div>
                </div>
            </form>
        </div>

        <?php
        $hostname = "localhost";
        $user = "root";
        $pass = "";
        $db = "pharmacy_management";

        $link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: " . mysqli_connect_error());

        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve form data
            $name = mysqli_real_escape_string($link, $_POST["name"]);
            $manufacturer = mysqli_real_escape_string($link, $_POST["manufacturer"]);
            $expiry_date = mysqli_real_escape_string($link, $_POST["expiry_date"]);
            $price = mysqli_real_escape_string($link, $_POST["price"]);
            $func = mysqli_real_escape_string($link, $_POST["func"]);
            $stock = mysqli_real_escape_string($link, $_POST["stock"]);
// Retrieve the last available ID
$getLastIdQuery = "SELECT MAX(medicine_id) AS last_id FROM Medicine";
$lastIdResult = mysqli_query($link, $getLastIdQuery);
$lastIdRow = mysqli_fetch_assoc($lastIdResult);
$lastId = $lastIdRow['last_id'];

// Increment the last ID to get the new ID
$newId = $lastId + 1;

// If there is no existing record, start from ID 1
if ($newId == null) {
    $newId = 1;
}

// Insert the new medicine with the new ID
$sql = "INSERT INTO Medicine (medicine_id, name, manufacturer, expiry_date, price, func, stock) 
        VALUES ($newId, '$name', '$manufacturer', '$expiry_date', '$price', '$func', $stock)";


            $insertResult = mysqli_query($link, $sql);

            if ($insertResult) {
                echo "Medicine added successfully!";

                // Display the updated medicine list
                $query = "SELECT * FROM Medicine";
                $result = mysqli_query($link, $query);

                echo "<h2 class='medicine-list'>Medicine List</h2>";

                if (mysqli_num_rows($result) > 0) {
                    echo "<table class='table table-bordered' style='background-color: #87CEEB;'>
            <thead class='thead-dark' style='background-color: #87CEEB;'> <!-- Change background color to dark blue -->
                            <tr>
                                <th>Medicine ID</th>
                                <th>Medicine Name</th>
                                <th>Manufacturer</th>
                                <th>Expiry Date</th>
                                <th>Function</th>
                                <th>Stock</th>
                            </tr>";

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>{$row['medicine_id']}</td>
                                <td>{$row['name']}</td>
                                <td>{$row['manufacturer']}</td>
                                <td>{$row['expiry_date']}</td>
                                <td>{$row['func']}</td>
                                <td>{$row['stock']}</td>
                            </tr>";
                    }

                    echo "</table>";
                } else {
                    echo "No records found.";
                }
            } else {
                // Check for duplicate entry error
                if (mysqli_errno($link) == 1062) {
                    echo "Error: Duplicate entry. Please try again.";
                } else {
                    echo "Error: " . mysqli_error($link);
                }
            }
        }

        mysqli_close($link);
        ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>


</html>

