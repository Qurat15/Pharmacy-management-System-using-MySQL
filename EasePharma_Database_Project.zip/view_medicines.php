<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

$link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: " . mysqli_connect_error());

echo "<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Pharmacy Management System</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
	    background: #fff;
        }

        .background-container {
            position: fixed;
            width: 100%;
            height: 100%;
            background: url('R.png') no-repeat center center fixed;
            background-size: cover;
            filter: blur(2px);
            z-index: -1;
        }

        th, td {
            border: 1px solid #87CEEB;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #87CEEB;
        }

        h1 {
            color: #fff;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>

<body>

    <!-- Background Container for Blur -->
    <div class='background-container'></div>

    <nav class='navbar navbar-expand-lg navbar-dark bg-dark'>
        <a class='navbar-brand' href='#'>Ease Pharma</a>
        <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNav'
            aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>
            <span class='navbar-toggler-icon'></span>
        </button>
        <div class='collapse navbar-collapse' id='navbarNav'>
            <ul class='navbar-nav ml-auto'>
                <li class='nav-item'>
                    <a class='nav-link' href='index.html'>Home</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='update_medicines.php'>Update Medicine</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='add_medicine.php'>Add Medicine</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='view_medicines.php'>View Medicines</a>
                </li>
		    <li class='nav-item'>
                    <a class='nav-link' href='delete_medicine.php'>Delete Medicines</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class='container'>
        <h1>Ease Pharma</h1>";

// Fetch all data from the medicine table
$query = "SELECT * FROM medicine";
$result = mysqli_query($link, $query);

// Check if there are rows in the result set
if (mysqli_num_rows($result) > 0) {
    // Display data in a table
    echo "<table class='table'>
            <thead class='thead-dark'>
                <tr>
                    <th>Medicine ID</th>
                    <th>Medicine Name</th>
                    <th>Manufacturer</th>
                    <th>Expiry Date</th>
                    <th>Function</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['medicine_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['manufacturer']}</td>
                <td>{$row['expiry_date']}</td>
                <td>{$row['func']}</td>
              </tr>";
    }

    echo "</tbody></table>";
} else {
    echo "<p>No records found.</p>";
}

// Close the database connection
mysqli_close($link);

echo "<script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
      <script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js'></script>
      <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>

      </body>

      </html>";
?>
