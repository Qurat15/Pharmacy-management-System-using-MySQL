<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "pharmacy_management";

// Establish database connection
$link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: " . mysqli_connect_error());


// Sanitize input values
$searchCriterion = mysqli_real_escape_string($link, $_POST["search_param"]);
$searchType = mysqli_real_escape_string($link, $_POST["search_type"]);

// Construct SQL query based on search criteria
if ($searchType == "Medicine ID") {
    $sql = "SELECT * FROM Medicine WHERE medicine_id = '$searchCriterion' ORDER BY name";
} elseif ($searchType == "Medicine Name") {
    $sql = "SELECT * FROM Medicine WHERE name LIKE '%$searchCriterion%' ORDER BY name";
} elseif ($searchType == "Manufacturer") {
    $sql = "SELECT * FROM Medicine WHERE manufacturer LIKE '%$searchCriterion%' ORDER BY name";
} elseif ($searchType == "Function") {
    $sql = "SELECT * FROM Medicine WHERE func LIKE '%$searchCriterion%' ORDER BY name";
} elseif ($searchType == "Expiry Date") {
    $sql = "SELECT * FROM Medicine WHERE expiry_date = '$searchCriterion' ORDER BY name";
} elseif ($searchType == "Stock") {
    $sql = "SELECT * FROM Medicine WHERE stock = '$searchCriterion' ORDER BY name";
} else {
    $sql = "SELECT * FROM Medicine ORDER BY name";
}

// Execute the query
$res = mysqli_query($link, $sql);

// Check for query success
if (!$res) {
    die('Query failed: ' . mysqli_error($link));
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease Pharma</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 10px;
        }

        th {
            background-color: #87CEEB;
        }

        h1, h3 {
            text-align:center;
	    color:#87CEEB;
        }
    </style>
</head>
<body>

<table>
    <tr>
        <td align="center">
            <h1>Ease Pharma</h1>
            <h3>Medicine Search Result(s)</h3>
        </td>
    </tr>
</table>

<?php
if (mysqli_num_rows($res) > 0) {
    echo "<p>There are " . mysqli_num_rows($res) . " result(s) available</p>";
    echo "<table>";
    echo "<tr>";
    echo "<th>Medicine ID</th>";
    echo "<th>Medicine Name</th>";
    echo "<th>Manufacturer</th>";
    echo "<th>Expiry Date</th>";
    echo "<th>Function</th>";
    echo "<th>Price</th>";
    echo "<th>Stock</th>";
    echo "</tr>";

    while ($data = mysqli_fetch_assoc($res)) {
        echo "<tr>";
        echo "<td>{$data['medicine_id']}</td>";
        echo "<td>{$data['name']}</td>";
        echo "<td>{$data['manufacturer']}</td>";
        echo "<td>{$data['expiry_date']}</td>";
        echo "<td>{$data['func']}</td>";
        echo "<td>{$data['price']}</td>";
        echo "<td>{$data['stock']}</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>No medicine found with your current search criterion: <strong>$searchType = \"$searchCriterion\"</strong></p>";
    echo "<p>Please recheck your searching criteria!</p>";
}

mysqli_close($link);
?>

</body>
</html>
