<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medicine - Ease Pharma</title>
    <style>
        /* Your existing styles remain unchanged */

        /* Add/update styles for the update form */
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div align="center">
        <h1>Ease Pharma</h1>
        <h3>Update Medicine</h3>

        <?php
        // Check if a medicine ID is provided
        if (isset($_GET['id'])) {
            $medicineId = $_GET['id'];

            // Fetch medicine details from the database based on ID
            // Replace the following code with your actual database connection and query
            $hostname = "localhost";
            $user = "root";
            $pass = "";
            $db = "pharmacy_management";

            $link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: ");

            $query = "SELECT * FROM medicine WHERE medicine_id = $medicineId";
            $result = mysqli_query($link, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                $medicine = mysqli_fetch_assoc($result);
            } else {
                echo "Medicine not found.";
                exit;
            }
        } else {
            echo "Medicine ID not provided.";
            exit;
        }
        ?>

        <form action="update_medicine.php" method="post">
            <input type="hidden" name="medicine_id" value="<?php echo $medicine['medicine_id']; ?>">

            <label for="medicine_name">Medicine Name:</label>
            <input type="text" name="medicine_name" value="<?php echo $medicine['medicine_name']; ?>" required>

            <label for="manufacturer">Manufacturer:</label>
            <input type="text" name="manufacturer" value="<?php echo $medicine['manufacturer']; ?>" required>

	    <label for="expiry_date">Expiry Date:</label>
            <input type="text" name="expiry_date" value="<?php echo $medicine['expiry_date']; ?>" required>

	    <label for="price">Price:</label>
            <input type="text" name="price" value="<?php echo $medicine['price']; ?>" required>


	    <label for="func">Function:</label>
            <input type="text" name="func" value="<?php echo $medicine['func']; ?>" required>

            <!-- Add other fields as needed -->

            <input type="submit" value="Update Medicine">
        </form>
    </div>
</body>

</html>
