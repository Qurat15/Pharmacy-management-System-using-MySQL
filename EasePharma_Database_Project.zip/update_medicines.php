<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Medicine - Pharmacy Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
 <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('R.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
            height: 100vh; /* Set full height of viewport */
        }

        /* Your existing styles here */

        .container {
            background-color: rgba(255, 255, 255, 0.8); /* Adjust opacity as needed */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px; /* Adjust spacing from the top */
        }
    </style>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Ease Pharma</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.html">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_medicine.php">Add Medicine</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_medicines.php">View Medicines</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="update_medicines.php">Update Medicine</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="delete_medicine.php">Delete Medicine</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="mb-4">Update Medicine</h2>

        <!-- Form for taking entries -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group row">
                <label for="medicineId" class="col-sm-2 col-form-label">Medicine ID:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="medicineId" name="medicine_id" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="medicineName" class="col-sm-2 col-form-label">Medicine Name:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="medicineName" name="name" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="manufacturer" class="col-sm-2 col-form-label">Manufacturer:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="manufacturer" name="manufacturer" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="expiryDate" class="col-sm-2 col-form-label">Expiry Date:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="expiryDate" name="expiry_date" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="price" class="col-sm-2 col-form-label">Price:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="price" name="price" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="func" class="col-sm-2 col-form-label">Function:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="func" name="func" required>
                </div>
            </div>
            <div class="form-group row">
                <label for="stock" class="col-sm-2 col-form-label">Stock:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="stock" name="stock" required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10 offset-sm-2">
                    <button type="submit" class="btn btn-primary">Update Medicine</button>
                </div>
            </div>
        </form>

        <?php
	$hostname = "localhost";
        $user = "root";
        $pass = "";
        $db = "pharmacy_management";

        $link = mysqli_connect($hostname, $user, $pass, $db) or die("Could not connect: ");

        // Function to fetch and display the medicine list
        function displayMedicineList($link)
        {
            $query = "SELECT * FROM medicine";
            $result = mysqli_query($link, $query);

            echo "<h2 class='mt-5'>Medicine List</h2>";

            if (mysqli_num_rows($result) > 0) {
                echo "<table class='table table-bordered'>
                        <tr>
                            <th>Medicine ID</th>
                            <th>Medicine Name</th>
                            <th>Manufacturer</th>
                            <th>Expiry Date</th>
                            <th>Function</th>
                            <th>Stock</th>
                        </tr>";

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['medicine_id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['manufacturer']}</td>
                            <td>{$row['expiry_date']}</td>
                            <td>{$row['func']}</td>
                            <td>{$row['stock']}</td>
                        </tr>";
                }

                echo "</table>";
            } else {
                echo "No records found.";
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Validate and sanitize input
            $medicineId = $_POST['medicine_id'];
            $medicineName = $_POST['name'];
            $manufacturer = $_POST['manufacturer'];
            $expiryDate = $_POST['expiry_date'];
            $price = $_POST['price'];
            $func = $_POST['func'];
            $stock = $_POST['stock'];

            // Replace the following code with your actual database connection and query
            $query = "UPDATE medicine SET 
                        name = '$medicineName',
                        manufacturer = '$manufacturer',	
                        expiry_date = '$expiryDate',
                        price = '$price',
                        func = '$func',
                        stock = '$stock'
                        WHERE medicine_id = $medicineId";

            $result = mysqli_query($link, $query);

            if ($result) {
                echo "<div class='alert alert-success mt-3'>Medicine updated successfully!</div>";

                // Display the updated medicine list
                displayMedicineList($link);
            } else {
                echo "<div class='alert alert-danger mt-3'>Error updating medicine: " . mysqli_error($link) . "</div>";
            }

            mysqli_close($link);
        }
        ?>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
